This zipfile contains multiple UML diagrams. In order to easy navigation, unzip the file to a folder first.

The diagrams are available in 2 formats: WMF format (in the Images_WMF folder) and PNG format (in the Images_PNG folder).

For every graphics format, you can find the following (if supplied by the Submitting Organisation):

- Activity diagrams (business flows) can be found in the BusinessFlows folder.
- Sequence diagrams (scenarios) can be found in the Scenarios folder.
- Message class diagrams (messages) can be found in the Messages folder.
